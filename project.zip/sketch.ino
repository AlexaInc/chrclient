void setup() {
  for(int i = 9; i <= 13; i++){
    pinMode(i, OUTPUT);
  }

}

void loop() {
int potrntiometerValue = analogRead(A0);
  int ledsToLight = 0;
  
  if (potrntiometerValue >= 1000) {
    ledsToLight = 5;
  } else if (potrntiometerValue >= 800) {
    ledsToLight = 4;
  } else if (potrntiometerValue >= 400) {
    ledsToLight = 3;
  } else if (potrntiometerValue >= 200) {
    ledsToLight = 2;
  } else if (potrntiometerValue >= 50) {
    ledsToLight = 1;
  } else {
    ledsToLight = 0; 
  }

  for (int i = 9; i <= 13; i++) {
    int ledIndex = i - 9;
    
    if (ledIndex < ledsToLight) {
      digitalWrite(i, HIGH);
    } else {
      digitalWrite(i, LOW);
    }
  }
  delay(100);

}
